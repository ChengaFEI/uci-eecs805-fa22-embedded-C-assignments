*******************************************
UCI Extension 2022Fall

EECS_805: C Programming for Embedded System
Module 2 Lab

Cheng Fei
*******************************************

Program: Segmentation Fail

main.c is the source code of my program and the outputs are included in Module2Lab.pdf. My program runs successfully without REGA definition and outputs results as desired. However, when using the REGA definition, it always alerts the segmentation failure whenever on a MAC OS or Windows OS.